param([string]$SetupConfigurationFile,[string]$JobStatusQuery)

function Write-HostWithLog{param([string]$Statement)
	$FileExists = Test-Path $LogFile
		If ($FileExists -eq $False) 
		{ New-Item $LogFile  -type file | Out-Null }
	$Date=Get-Date
	$DisplayStatement = $Date.ToString() + " " + $Statement
	Add-Content $LogFile $DisplayStatement
	Write-Host $Statement

}

#This function will Write to console with foreground color and in log file
function Write-HostWithLogandColor{param([string]$Statement,[string]$Color)
	$FileExists = Test-Path $LogFile
		If ($FileExists -eq $False) 
		{ New-Item $LogFile -type file | Out-Null }

	$Date=Get-Date
	$DisplayStatement = $Date.ToString() + " " + $Statement
	Add-Content $LogFile $DisplayStatement
	Write-Host $Statement -ForegroundColor $Color

}

function TestPath{param([string]$FolderPath,[string]$Message)
	if(Test-Path ($FolderPath))
	{
	Write-host $Temp -ForegroundColor Gray
	Write-host "$FolderPath $Message folder Path is valid" -ForegroundColor Gray
	Write-host $TempNewLine -ForegroundColor Gray
	}
	else
	{
	Write-host $TempNewLine -ForegroundColor Red
	Write-host "$FolderPath $Message folder path is invalid `n" -ForegroundColor Red
	Write-host $Temp -ForegroundColor Red
	throw "Please enter correct folder path"
	exit 1;
	}
}


	$Temp ="%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%"
	$TempNewLine ="%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% `n `n"
	[xml]$xmlConfigFile = new-object XML
	$xmlConfigFile.Load($SetupConfigurationFile)
	$LogFile_FolderPath=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/LogFile_FolderPath").getAttribute("Log_FolderPath_M")
	TestPath $LogFile_FolderPath "Log"
	$LogFile=$LogFile_FolderPath + "\Log.txt"
	$Build_FolderPath_M=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Build_FolderPath").getAttribute("Build_FolderPath_M")
	TestPath $Build_FolderPath_M "Build"

	$FrameworkRequired=$xmlConfigFile.selectSingleNode("/Configuration/Component").getAttribute("Framework")
	$FW_Build_Verification_Required=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BuildVerification").getAttribute("FW_Build_Verification_Required")
	write-host $FW_Build_Verification_Required
	$Framework_Web_ServicesRequired=$xmlConfigFile.selectSingleNode("/Configuration/Component").getAttribute("Framework_Web_Services")
	$JRERequired=$xmlConfigFile.selectSingleNode("/Configuration/Component").getAttribute("JRE")
	$SSIS_Jobs_Required=$xmlConfigFile.selectSingleNode("/Configuration/Framework/Framework_Components_Required").getAttribute("B_SSIS_Packages_Required")
	$BIC_Datamart_Required=$xmlConfigFile.selectSingleNode("/Configuration/Framework/Framework_Components_Required").getAttribute("A_BIC_Datamart_Required")
	$RMMRequired=$xmlConfigFile.selectSingleNode("/Configuration/Component").getAttribute("RMM")
	$RMM_Datamart_Required=$xmlConfigFile.selectSingleNode("/Configuration/RMM/RMM_Components_Required").getAttribute("B_RMM_Datamart_Required")
	$RMM_SSIS_Jobs_Required=$xmlConfigFile.selectSingleNode("/Configuration/RMM/RMM_Components_Required").getAttribute("C_SSIS_Packages_Required")
	$RMM_Application_Required=$xmlConfigFile.selectSingleNode("/Configuration/RMM/RMM_Components_Required").getAttribute("A_RMM_Application_Required")
	$Perform_Plus_Required=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Framework_Web_Services_Components_Required").getAttribute("Perform_Plus_Required")
	
	#Write-HostWithLogandColor "Log Path $LogFile" Green

	$dashline = "---------------------------------------------------------------------------"
#ExecuteInstallers
function ExecuteInstallers
{	
Write-Host "Started Installation"

If(([string]::IsNullOrEmpty($Error)) -and [string]$FrameworkRequired -eq "true")
{
If(([string]::IsNullOrEmpty($Error))-and [string]$FW_Build_Verification_Required -eq "true")
{
	$PreDeployment="True"
	$PostDeployment="False"
Write-Host "Started Pre Build Verification"
$Installer=".\BUILDVerification.ps1"
& $Installer $SetupConfigurationFile $JobStatusQuery $PreDeployment $PostDeployment
}	
	
If(([string]::IsNullOrEmpty($Error))-and [string]$BIC_Datamart_Required -eq "true")
{
Write-Host "Started BICDataMart Installation"
$Installer=".\BICDataMart.ps1"
& $Installer $SetupConfigurationFile
}
If(([string]::IsNullOrEmpty($Error))-and [string]$SSIS_Jobs_Required -eq "true")
{
Write-Host "Started Downstream Installation"
$Installer=".\Downstream.ps1"
& $Installer $SetupConfigurationFile $JobStatusQuery
}

If(([string]::IsNullOrEmpty($Error))-and [string]$FW_Build_Verification_Required -eq "true")
{
	$PreDeployment="False"
	$PostDeployment="True"
Write-Host "Started Post Build Verification"
$Installer=".\BUILDVerification.ps1"
& $Installer $SetupConfigurationFile $JobStatusQuery $PreDeployment $PostDeployment
}
}
If(([string]::IsNullOrEmpty($Error)) -and [string]$Framework_Web_ServicesRequired -eq "true" -and [string]$Perform_Plus_Required -eq "true")
{
Write-Host "Started Perform_Plus Webservice Utils Installation"
$Installer=".\Perform_Plus.ps1"
& $Installer $SetupConfigurationFile
}
If(([string]::IsNullOrEmpty($Error)) -and [string]$Framework_Web_ServicesRequired -eq "true")
{
Write-Host "Started Framework Webservice Utils Installation"
$Installer=".\UtilsPowerShell.ps1"
& $Installer $SetupConfigurationFile
}
If(([string]::IsNullOrEmpty($Error)) -and [string]$JRERequired -eq "true")
{
Write-Host "Started JRE Utils Installation"
$Installer=".\UtilsPowerShell_CQM.ps1"
& $Installer $SetupConfigurationFile
}
If(([string]::IsNullOrEmpty($Error)) -and [string]$RMMRequired -eq "true")
{
If(([string]::IsNullOrEmpty($Error))-and [string]$RMM_Datamart_Required -eq "true")
{
Write-Host "Started RMMDataMart Installation"
$Installer=".\BICDataMartRMM.ps1"
& $Installer $SetupConfigurationFile
}
If(([string]::IsNullOrEmpty($Error))-and [string]$RMM_SSIS_Jobs_Required -eq "true")
{
Write-Host "Started RMM SSIS Job's Installation"
$Installer=".\Downstream_RMM.ps1"
& $Installer $SetupConfigurationFile $JobStatusQuery
}
If(([string]::IsNullOrEmpty($Error))-and [string]$RMM_Application_Required -eq "true")
{
Write-Host "Started RMM Application Installation"
$Installer=".\UtilsPowerShell_RMM.ps1"
& $Installer $SetupConfigurationFile
}
}
}

ExecuteInstallers
if($Error -ne "")
{
Write-HostWithLogandColor $Error Magenta
}
else
{
Write-HostWithLog "Master script executed successfully"
}