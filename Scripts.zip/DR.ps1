param([string]$SetupConfigurationFile,[string]$SetupConfigurationFile_bak)
# Framework config load
$PathDR = "$(get-location)\DataRepresentation.config"
$PathDR_bak="$(get-location)\DataRepresentation_bak.config"
#Region for Framework
if ((( Test-Path $PathDR) -eq "True") -and ((Test-Path $PathDR_bak) -eq "True"))
{
ECHO "DataRepresentation Config Exits"
[xml]$xmlConfigFile_bak = new-object XML
$xmlConfigFile_bak.Load($SetupConfigurationFile_bak)

# Framework Copy existing values form the backup config file 
$Clinical_DB_Server=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("A_Clinical_DB_Server_M")
$Clinical_SSIS_Server=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("B_Clinical_SSIS_Server_M")
$Clinical_DB_Port=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("C_Clinical_DB_Port_M")
$Clinical_SSIS_Port=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("C_Clinical_SSIS_Port_M")
$Clinical_DB_Name=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("D_Clinical_DB_Name_M")
$E_Clinical_DB_Authentication=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("E_Clinical_DB_Authentication")
$F_Clinical_SQL_User=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("F_Clinical_SQL_User")
$G_Clinical_SQL_Password=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("G_Clinical_SQL_Password")
$Clinical_SSIS_FolderPath=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("H_Clinical_SSIS_FolderPath_M")
$Clinical_SSIS_Absolute_FolderPath=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("I_Clinical_SSIS_Absolute_FolderPath_M")
$J_Clinical_Data_FilePath=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("J_Clinical_Data_FilePath")
$K_Clinical_Log_FilePath=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("K_Clinical_Log_FilePath")
$NetezzaServer=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("NetezzaServer")
$IsHttps_Required=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/Web_String").getAttribute("IsHttps_Required")
$IsSSO_Required=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/Web_String").getAttribute("IsSSO_Required")

#RMM_Server_Details
$A_RMM_DB_Server=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").getAttribute("A_RMM_DB_Server_M")
$B_RMM_SSIS_Server=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").getAttribute("B_RMM_SSIS_Server_M")
$C_RMM_DB_Port=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").getAttribute("C_RMM_DB_Port_M")
$C_RMM_SSIS_Port=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").getAttribute("C_RMM_SSIS_Port_M")
$D_RMM_DB_Name=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").getAttribute("D_RMM_DB_Name_M")
$E_RMM_DB_Authentication=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").getAttribute("E_RMM_DB_Authentication")
$F_RMM_SQL_User=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").getAttribute("F_RMM_SQL_User")
$G_RMM_SQL_Password=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").getAttribute("G_RMM_SQL_Password")
$H_RMM_SSIS_FolderPath=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").getAttribute("H_RMM_SSIS_FolderPath_M")
$I_RMM_SSIS_Absolute_FolderPath=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").getAttribute("I_RMM_SSIS_Absolute_FolderPath_M")
$J_RMM_Data_FilePath=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").getAttribute("J_RMM_Data_FilePath")
$K_RMM_Log_FilePath=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").getAttribute("K_RMM_Log_FilePath")
#JREServer
$JRE_Server_Name=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/JREServer").getAttribute("JRE_Server_Name")
$JRE_Server_Port=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/JREServer").getAttribute("JRE_Server_Port")
#RMM SMTP
$SMTP_Server_Name=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/SMTP").getAttribute("A_SMTP_Server_Name")	
$SMTP_Port=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/SMTP").getAttribute("B_SMTP_Port")	
$SMTP_User_Name=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/SMTP").getAttribute("C_SMTP_User_Name")	
$SMTP_Password=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/SMTP").getAttribute("D_SMTP_Password")	
#MRR Server Details
$MRR_SSIS_Absolute_FolderPath=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/MRR_Packages").getAttribute("FolderPath")
ECHO $MRR_SSIS_Absolute_FolderPath
if($MRR_SSIS_Absolute_FolderPath -eq $null -or $MRR_SSIS_Absolute_FolderPath -eq "" )
{
$MRR_SSIS_Absolute_FolderPath=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/MRR_Server_Details").getAttribute("MRR_SSIS_Absolute_FolderPath")
}
$MRR_DB_Name=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/MRR_Server_Details").getAttribute("MRR_DB_Name")
#Source_DB_Server_Details
$A_Source_DB_Server=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/Source_DB_Server_Details").getAttribute("A_Source_DB_Server")
$B_Source_DB_Name=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/Source_DB_Server_Details").getAttribute("B_Source_DB_Name")
$C_Source_DB_Authentication=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/Source_DB_Server_Details").getAttribute("C_Source_DB_Authentication")
$D_Source_SQL_User=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/Source_DB_Server_Details").getAttribute("D_Source_SQL_User")
$E_Source_SQL_Password=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/Source_DB_Server_Details").getAttribute("E_Source_SQL_Password")
#UAM_Server_Details
$Auth_Server_Name=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/UAM_Server_Details").getAttribute("Auth_Server_Name")
$Auth_Server_Port=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/UAM_Server_Details").getAttribute("Auth_Server_Port")
$UAMApp_Server_Name=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/UAM_Server_Details").getAttribute("UAMApp_Server_Name")
$UAMApp_Server_Port=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/UAM_Server_Details").getAttribute("UAMApp_Server_Port")
$UAMWeb_Server_Name=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/UAM_Server_Details").getAttribute("UAMWeb_Server_Name")
$UAMWeb_Server_Port=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/UAM_Server_Details").getAttribute("UAMWeb_Server_Port")
#Clinical_App_ConnectionString
$A_Clinical_App_Authentication=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/Clinical_App_ConnectionString").getAttribute("A_Clinical_App_Authentication")
$B_Clinical_App_SQL_User=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/Clinical_App_ConnectionString").getAttribute("B_Clinical_App_SQL_User")
$C_Clinical_App_SQL_Password=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/Clinical_App_ConnectionString").getAttribute("C_Clinical_App_SQL_Password")

#RMM_App_Connectionstring
$A_RMM_App_Authentication=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/RMM_App_Connectionstring").getAttribute("A_RMM_App_Authentication")
$B_RMM_App_SQL_User=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/RMM_App_Connectionstring").getAttribute("B_RMM_App_SQL_User")
$C_RMM_App_SQL_Password=$xmlConfigFile_bak.selectSingleNode("/Configuration/Common_Parameter/RMM_App_Connectionstring").getAttribute("C_RMM_App_SQL_Password")

#Framework
$BIC_Datamart_Required=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework/Framework_Components_Required").getAttribute("A_BIC_Datamart_Required")
$SSIS_Packages_Required=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework/Framework_Components_Required").getAttribute("B_SSIS_Packages_Required")
$SSIS_Jobs_Required=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework/Framework_Components_Required").getAttribute("C_SSIS_Jobs_Required")
$IsPartition_Required=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework/TablePartition").getAttribute("IsPartition_Required_M")
$No_Of_Partition=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework/IsPartition").getAttribute("No_Of_Partition_M")
$Job_Owner=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework/Framework_SQL_Agent_Job").getAttribute("Job_Owner")
$Job_Prefix=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework/Framework_SQL_Agent_Job").getAttribute("Job_Prefix")
$Proxy_Name=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework/Framework_SQL_Agent_Job").getAttribute("Proxy_Name")
$Dynamic_Index_Required=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework/Framework_SQL_Agent_Job").getAttribute("Dynamic_Index_Required")
$Email_ID=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework/Framework_SMTP").getAttribute("Email_ID")
$Enviroment=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework/Framework_SMTP").getAttribute("Enviroment")
$Server_Name=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework/Framework_SMTP").getAttribute("Server_Name")
#RMM
$RMM_Application_Required=$xmlConfigFile_bak.selectSingleNode("/Configuration/RMM/RMM_Components_Required").getAttribute("A_RMM_Application_Required")
$RMM_Datamart_Required=$xmlConfigFile_bak.selectSingleNode("/Configuration/RMM/RMM_Components_Required").getAttribute("B_RMM_Datamart_Required")
$RMM_SSIS_Packages_Required=$xmlConfigFile_bak.selectSingleNode("/Configuration/RMM/RMM_Components_Required").getAttribute("C_SSIS_Packages_Required")
$RMM_SSIS_Jobs_Required=$xmlConfigFile_bak.selectSingleNode("/Configuration/RMM/RMM_Components_Required").getAttribute("D_SSIS_Jobs_Required")
#RMM SQL_Agent_Job
$RMM_Job_Prefix=$xmlConfigFile_bak.selectSingleNode("/Configuration/RMM/SQL_Agent_Job").getAttribute("Job_Prefix")
$RMM_Job_Owner=$xmlConfigFile_bak.selectSingleNode("/Configuration/RMM/SQL_Agent_Job").getAttribute("Job_Owner")
$RMM_Proxy_Name=$xmlConfigFile_bak.selectSingleNode("/Configuration/RMM/SQL_Agent_Job").getAttribute("Proxy_Name")
#RMM UI_Server_Details
$A_RMM_Web_War_Required=$xmlConfigFile_bak.selectSingleNode("/Configuration/RMM/UI_Server_Details").getAttribute("A_RMM_Web_War_Required")
$B_RMM_Web_Properties_Required=$xmlConfigFile_bak.selectSingleNode("/Configuration/RMM/UI_Server_Details").getAttribute("B_RMM_Web_Properties_Required")
$C_RMM_Web_Server_Name=$xmlConfigFile_bak.selectSingleNode("/Configuration/RMM/UI_Server_Details").getAttribute("C_RMM_Web_Server_Name_M")
$D_RMM_Web_Port=$xmlConfigFile_bak.selectSingleNode("/Configuration/RMM/UI_Server_Details").getAttribute("D_RMM_Web_Port_M")
$F_RMM_Web_Server_Path=$xmlConfigFile_bak.selectSingleNode("/Configuration/RMM/UI_Server_Details").getAttribute("F_RMM_Web_Server_Path_M")
#RMM Service_Server_Details
$A_RMM_App_War_Required=$xmlConfigFile_bak.selectSingleNode("/Configuration/RMM/Service_Server_Details").getAttribute("A_RMM_App_War_Required")
$B_RMM_App_Properties_Required=$xmlConfigFile_bak.selectSingleNode("/Configuration/RMM/Service_Server_Details").getAttribute("B_RMM_App_Properties_Required")
$C_RMM_APP_Server_Name=$xmlConfigFile_bak.selectSingleNode("/Configuration/RMM/Service_Server_Details").getAttribute("C_RMM_APP_Server_Name_M")
$D_RMM_APP_Port=$xmlConfigFile_bak.selectSingleNode("/Configuration/RMM/Service_Server_Details").getAttribute("D_RMM_APP_Port_M")
$E_RMM_APP_Server_Path=$xmlConfigFile_bak.selectSingleNode("/Configuration/RMM/Service_Server_Details").getAttribute("E_RMM_APP_Server_Path_M")
#RMM Rules_Folder
$Export_Folder_Path=$xmlConfigFile_bak.selectSingleNode("/Configuration/RMM/Rules_Folder").getAttribute("Export_Folder_Path_M")
$Import_Folder_Path=$xmlConfigFile_bak.selectSingleNode("/Configuration/RMM/Rules_Folder").getAttribute("Import_Folder_Path_M")
#RMM Private_Server_Details
$Private_Server_Name=$xmlConfigFile_bak.selectSingleNode("/Configuration/RMM/Private_Server_Details").getAttribute("Private_Server_Name")
$Private_Server_Port=$xmlConfigFile_bak.selectSingleNode("/Configuration/RMM/Private_Server_Details").getAttribute("Private_Server_Port")
#Additonal_CORS_Allowed_Origin
$Additonal_CORS_Allowed_Origin=$xmlConfigFile_bak.selectSingleNode("/Configuration/RMM/Additonal_CORS_Allowed_Origin").getAttribute("URL")
#RMM Common
$RMM_SCHEDULER_INTERVAL=$xmlConfigFile_bak.selectSingleNode("/Configuration/RMM/Common").getAttribute("SCHEDULER_INTERVAL")
$RMM_START_DELAY=$xmlConfigFile_bak.selectSingleNode("/Configuration/RMM/Common").getAttribute("START_DELAY")
#RMM Authentication_Type
$LDAP_Required=$xmlConfigFile_bak.selectSingleNode("/Configuration/RMM/Authentication_Type").getAttribute("LDAP_Required")
$UAM_Required=$xmlConfigFile_bak.selectSingleNode("/Configuration/RMM/Authentication_Type").getAttribute("UAM_Required")
#RMM LDAP
$A_LDAP_Url=$xmlConfigFile_bak.selectSingleNode("/Configuration/RMM/LDAP").getAttribute("A_LDAP_Url")
$B_LDAP_Domain=$xmlConfigFile_bak.selectSingleNode("/Configuration/RMM/LDAP").getAttribute("B_LDAP_Domain")
$C_LDAP_Group_Name=$xmlConfigFile_bak.selectSingleNode("/Configuration/RMM/LDAP").getAttribute("C_LADAP_Group_Name")
###################################################################################################################
#RMM_UAM
$A_Auth_Web_ClientId=$xmlConfigFile_bak.selectSingleNode("/Configuration/RMM/UAM").getAttribute("A_Auth_Web_Client_ID")
$B_Auth_App_ClientId=$xmlConfigFile_bak.selectSingleNode("/Configuration/RMM/UAM").getAttribute("B_Auth_App_Client_ID")
$C_Auth_App_Client_Secret=$xmlConfigFile_bak.selectSingleNode("/Configuration/RMM/UAM").getAttribute("C_Auth_App_Client_Secret")
$F_Admin_Console_Auth_Web_Client_ID=$xmlConfigFile_bak.selectSingleNode("/Configuration/RMM/UAM").getAttribute("A_Auth_Web_Client_ID")
##################################################################################################################
#JRE_App
$A_JRE_War_Required=$xmlConfigFile_bak.selectSingleNode("/Configuration/JRE/JRE_Components_Required").getAttribute("A_JRE_War_Required")
$B_JRE_Properties_Required=$xmlConfigFile_bak.selectSingleNode("/Configuration/JRE/JRE_Components_Required").getAttribute("B_JRE_Properties_Required")
$JRE_App_Server_Path=$xmlConfigFile_bak.selectSingleNode("/Configuration/JRE/JRE_App_Path").getAttribute("JRE_App_Server_Path_M")
#Framework_Web_Services
$GPRO_Required=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework_Web_Services/Framework_Web_Services_Components_Required").getAttribute("GPRO_Required")
$HEDIS_Submission_Required=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework_Web_Services/Framework_Web_Services_Components_Required").getAttribute("HEDIS_Submission_Required")
$PMS_Required=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework_Web_Services/Framework_Web_Services_Components_Required").getAttribute("PMS_Required")
$QPPDS_Required=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework_Web_Services/Framework_Web_Services_Components_Required").getAttribute("QPPDS_Required")
$QPP_Required=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework_Web_Services/Framework_Web_Services_Components_Required").getAttribute("QPP_Required")
$QRDAIII_Required=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework_Web_Services/Framework_Web_Services_Components_Required").getAttribute("QRDAIII_Required")
$QRDAI_Required=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework_Web_Services/Framework_Web_Services_Components_Required").getAttribute("QRDAI_Required")
$State_Level_Submission_Required=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework_Web_Services/Framework_Web_Services_Components_Required").getAttribute("State_Level_Submission_Required")
$Wrapper_Services_Required=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework_Web_Services/Framework_Web_Services_Components_Required").getAttribute("Wrapper_Services_Required")
$CohortQR_Required=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework_Web_Services/Framework_Web_Services_Components_Required").getAttribute("CohortQR_Required")

$GPRO_Year=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework_Web_Services/Year").getAttribute("GPRO_Year")
$QPPDS_Year=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework_Web_Services/Year").getAttribute("QPPDS_Year")
$QPP_Year=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework_Web_Services/Year").getAttribute("QPP_Year")
$QRDAIII_Year=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework_Web_Services/Year").getAttribute("QRDAIII_Year")
$QRDAI_Year=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework_Web_Services/Year").getAttribute("QRDAI_Year")
$State_Level_Submission_Year=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework_Web_Services/Year").getAttribute("State_Level_Submission_Year")
$CohortQR_Year=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework_Web_Services/Year").getAttribute("CohortQR_Year")
#Framework_Web_Services UI_Server_Details_Framework
$A_Framework_Web_Server_Name=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework_Web_Services/UI_Server_Details_Framework").getAttribute("A_Framework_Web_Server_Name")
$B_Framework_Web_Port=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework_Web_Services/UI_Server_Details_Framework").getAttribute("B_Framework_Web_Port")
$C_Framework_Web_Server_Path=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework_Web_Services/UI_Server_Details_Framework").getAttribute("C_Framework_Web_Server_Path")
#Framework_Web_Services Service_Server_Details_Framework
$A_Framework_APP_Server_Name=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework_Web_Services/Service_Server_Details_Framework").getAttribute("A_Framework_APP_Server_Name_M")
$B_Framework_APP_Port=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework_Web_Services/Service_Server_Details_Framework").getAttribute("B_Framework_APP_Port_M")
$C_Framework_APP_Server_Path=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework_Web_Services/Service_Server_Details_Framework").getAttribute("C_Framework_APP_Server_Path_M")
#Framework_Web_Services Wrapper_Service_Output_Folder_Path
$Wrapper_Service_Output_Folder_Path=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework_Web_Services/Wrapper_Service").getAttribute("Output_Folder_Path")
#UAM Auth client ID for HEDIS
$FW_Auth_Web_ClientId=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework_Web_Services/UAM_Auth").getAttribute("Web_Client_ID")
$App_Client_ID=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework_Web_Services/UAM_Auth").getAttribute("App_Client_ID")
$App_client_Secret=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework_Web_Services/UAM_Auth").getAttribute("App_client_Secret")
#PerformPlus Auth client ID
$PerformPlus_App_Client_ID=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework_Web_Services/Perform_Plus_UAM_Auth").getAttribute("App_Client_ID")
$PerformPlus_App_Client_Secret=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework_Web_Services/Perform_Plus_UAM_Auth").getAttribute("App_Client_Secret")
$PerformPlus_Web_Client_ID=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework_Web_Services/Perform_Plus_UAM_Auth").getAttribute("Web_Client_ID")
#Framework Private Server Details
$Framework_Private_Server_Name=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework_Web_Services/Private_Server_Details_Framework").getAttribute("Private_Server_Name")
$Framework_Private_Server_Port=$xmlConfigFile_bak.selectSingleNode("/Configuration/Framework_Web_Services/Private_Server_Details_Framework").getAttribute("Private_Server_Port")

# Framework copy values in the datarepsenation config file
[xml]$xmlConfigFile = new-object XML
$xmlConfigFile.Load($SetupConfigurationFile)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").setAttribute("A_Clinical_DB_Server_M",$Clinical_DB_Server)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").setAttribute("B_Clinical_SSIS_Server_M",$Clinical_SSIS_Server)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").setAttribute("C_Clinical_DB_Port_M",$Clinical_DB_Port)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").setAttribute("C_Clinical_SSIS_Port_M",$Clinical_SSIS_Port)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").setAttribute("D_Clinical_DB_Name_M",$Clinical_DB_Name)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").setAttribute("E_Clinical_DB_Authentication",$E_Clinical_DB_Authentication)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").setAttribute("F_Clinical_SQL_User",$F_Clinical_SQL_User)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").setAttribute("G_Clinical_SQL_Password",$G_Clinical_SQL_Password)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").setAttribute("H_Clinical_SSIS_FolderPath_M",$Clinical_SSIS_FolderPath)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").setAttribute("I_Clinical_SSIS_Absolute_FolderPath_M",$Clinical_SSIS_Absolute_FolderPath)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").setAttribute("J_Clinical_Data_FilePath",$J_Clinical_Data_FilePath)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").setAttribute("K_Clinical_Log_FilePath",$K_Clinical_Log_FilePath)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").setAttribute("NetezzaServer",$NetezzaServer)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Web_String").setAttribute("IsHttps_Required",$IsHttps_Required)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Web_String").setAttribute("IsSSO_Required",$IsSSO_Required)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").setAttribute("A_RMM_DB_Server_M",$A_RMM_DB_Server)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").setAttribute("B_RMM_SSIS_Server_M",$B_RMM_SSIS_Server)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").setAttribute("C_RMM_DB_Port_M",$C_RMM_DB_Port)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").setAttribute("C_RMM_SSIS_Port_M",$C_RMM_SSIS_Port)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").setAttribute("D_RMM_DB_Name_M",$D_RMM_DB_Name)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").setAttribute("E_RMM_DB_Authentication",$E_RMM_DB_Authentication)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").setAttribute("F_RMM_SQL_User",$F_RMM_SQL_User)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").setAttribute("G_RMM_SQL_Password",$G_RMM_SQL_Password)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").setAttribute("H_RMM_SSIS_FolderPath_M",$H_RMM_SSIS_FolderPath)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").setAttribute("I_RMM_SSIS_Absolute_FolderPath_M",$I_RMM_SSIS_Absolute_FolderPath)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").setAttribute("J_RMM_Data_FilePath",$J_RMM_Data_FilePath)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/RMM_Server_Details").setAttribute("K_RMM_Log_FilePath",$K_RMM_Log_FilePath)
#JRE Server
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/JREServer").setAttribute("JRE_Server_Name",$JRE_Server_Name)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/JREServer").setAttribute("JRE_Server_Port",$JRE_Server_Port)
#SMTP Details
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/SMTP").setAttribute("A_SMTP_Server_Name",$SMTP_Server_Name)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/SMTP").setAttribute("B_SMTP_Port",$SMTP_Port)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/SMTP").setAttribute("C_SMTP_User_Name",$SMTP_User_Name)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/SMTP").setAttribute("D_SMTP_Password",$SMTP_Password)
#MRR_Server_Details
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/MRR_Server_Details").setAttribute("MRR_SSIS_Absolute_FolderPath",$MRR_SSIS_Absolute_FolderPath)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/MRR_Server_Details").setAttribute("MRR_DB_Name",$MRR_DB_Name)
#Source_DB_Server_Details
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Source_DB_Server_Details").setAttribute("A_Source_DB_Server",$A_Source_DB_Server)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Source_DB_Server_Details").setAttribute("B_Source_DB_Name",$B_Source_DB_Name)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Source_DB_Server_Details").setAttribute("C_Source_DB_Authentication",$C_Source_DB_Authentication)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Source_DB_Server_Details").setAttribute("D_Source_SQL_User",$D_Source_SQL_User)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Source_DB_Server_Details").setAttribute("E_Source_SQL_Password",$E_Source_SQL_Password)
#UAM_Server_Details
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/UAM_Server_Details").setAttribute("Auth_Server_Name",$Auth_Server_Name)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/UAM_Server_Details").setAttribute("Auth_Server_Port",$Auth_Server_Port)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/UAM_Server_Details").setAttribute("UAMApp_Server_Name",$UAMApp_Server_Name)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/UAM_Server_Details").setAttribute("UAMApp_Server_Port",$UAMApp_Server_Port)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/UAM_Server_Details").setAttribute("UAMWeb_Server_Name",$UAMWeb_Server_Name)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/UAM_Server_Details").setAttribute("UAMWeb_Server_Port",$UAMWeb_Server_Port)

#Clinical_App_ConnectionString
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Clinical_App_ConnectionString").setAttribute("A_Clinical_App_Authentication",$A_Clinical_App_Authentication)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Clinical_App_ConnectionString").setAttribute("B_Clinical_App_SQL_User",$B_Clinical_App_SQL_User)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Clinical_App_ConnectionString").setAttribute("C_Clinical_App_SQL_Password",$C_Clinical_App_SQL_Password)

#RMM_App_Connectionstring
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/RMM_App_Connectionstring").setAttribute("A_RMM_App_Authentication",$A_RMM_App_Authentication)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/RMM_App_Connectionstring").setAttribute("B_RMM_App_SQL_User",$B_RMM_App_SQL_User)
$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/RMM_App_Connectionstring").setAttribute("C_RMM_App_SQL_Password",$C_RMM_App_SQL_Password)
#Framework
$xmlConfigFile.selectSingleNode("/Configuration/Framework/Framework_Components_Required").setAttribute("A_BIC_Datamart_Required",$BIC_Datamart_Required)
$xmlConfigFile.selectSingleNode("/Configuration/Framework/Framework_Components_Required").setAttribute("B_SSIS_Packages_Required",$SSIS_Packages_Required)
$xmlConfigFile.selectSingleNode("/Configuration/Framework/Framework_Components_Required").setAttribute("C_SSIS_Jobs_Required",$SSIS_Jobs_Required)
$xmlConfigFile.selectSingleNode("/Configuration/Framework/TablePartition").setAttribute("IsPartition_Required_M",$IsPartition_Required)
$xmlConfigFile.selectSingleNode("/Configuration/Framework/IsPartition").setAttribute("No_Of_Partition_M",$No_Of_Partition)
$xmlConfigFile.selectSingleNode("/Configuration/Framework/Framework_SQL_Agent_Job").setAttribute("Job_Owner",$Job_Owner)
$xmlConfigFile.selectSingleNode("/Configuration/Framework/Framework_SQL_Agent_Job").setAttribute("Job_Prefix",$Job_Prefix)
$xmlConfigFile.selectSingleNode("/Configuration/Framework/Framework_SQL_Agent_Job").setAttribute("Proxy_Name",$Proxy_Name)
$xmlConfigFile.selectSingleNode("/Configuration/Framework/Framework_SQL_Agent_Job").setAttribute("Dynamic_Index_Required",$Dynamic_Index_Required)
$xmlConfigFile.selectSingleNode("/Configuration/Framework/Framework_SMTP").setAttribute("Email_ID",$Email_ID)
$xmlConfigFile.selectSingleNode("/Configuration/Framework/Framework_SMTP").setAttribute("Enviroment",$Enviroment)
$xmlConfigFile.selectSingleNode("/Configuration/Framework/Framework_SMTP").setAttribute("Server_Name",$Server_Name)

#RMM
$xmlConfigFile.selectSingleNode("/Configuration/RMM/RMM_Components_Required").setAttribute("A_RMM_Application_Required",$RMM_Application_Required)
$xmlConfigFile.selectSingleNode("/Configuration/RMM/RMM_Components_Required").setAttribute("B_RMM_Datamart_Required",$RMM_Datamart_Required)
$xmlConfigFile.selectSingleNode("/Configuration/RMM/RMM_Components_Required").setAttribute("C_SSIS_Packages_Required",$RMM_SSIS_Packages_Required)
$xmlConfigFile.selectSingleNode("/Configuration/RMM/RMM_Components_Required").setAttribute("D_SSIS_Jobs_Required",$RMM_SSIS_Jobs_Required)

#RMM SQL_Agent_Job
$xmlConfigFile.selectSingleNode("/Configuration/RMM/SQL_Agent_Job").setAttribute("Job_Prefix",$RMM_Job_Prefix)
$xmlConfigFile.selectSingleNode("/Configuration/RMM/SQL_Agent_Job").setAttribute("Job_Owner",$RMM_Job_Owner)
$xmlConfigFile.selectSingleNode("/Configuration/RMM/SQL_Agent_Job").setAttribute("Proxy_Name",$RMM_Proxy_Name)
#RMM UI_Server_Details
$xmlConfigFile.selectSingleNode("/Configuration/RMM/UI_Server_Details").setAttribute("A_RMM_Web_War_Required",$A_RMM_Web_War_Required)
$xmlConfigFile.selectSingleNode("/Configuration/RMM/UI_Server_Details").setAttribute("B_RMM_Web_Properties_Required",$B_RMM_Web_Properties_Required)
$xmlConfigFile.selectSingleNode("/Configuration/RMM/UI_Server_Details").setAttribute("C_RMM_Web_Server_Name_M",$C_RMM_Web_Server_Name)
$xmlConfigFile.selectSingleNode("/Configuration/RMM/UI_Server_Details").setAttribute("D_RMM_Web_Port_M",$D_RMM_Web_Port)
$xmlConfigFile.selectSingleNode("/Configuration/RMM/UI_Server_Details").setAttribute("F_RMM_Web_Server_Path_M",$F_RMM_Web_Server_Path)
#RMM Service_Server_Details
$xmlConfigFile.selectSingleNode("/Configuration/RMM/Service_Server_Details").setAttribute("A_RMM_App_War_Required",$A_RMM_App_War_Required)
$xmlConfigFile.selectSingleNode("/Configuration/RMM/Service_Server_Details").setAttribute("B_RMM_App_Properties_Required",$B_RMM_App_Properties_Required)
$xmlConfigFile.selectSingleNode("/Configuration/RMM/Service_Server_Details").setAttribute("C_RMM_APP_Server_Name_M",$C_RMM_APP_Server_Name)
$xmlConfigFile.selectSingleNode("/Configuration/RMM/Service_Server_Details").setAttribute("D_RMM_APP_Port_M",$D_RMM_APP_Port)
$xmlConfigFile.selectSingleNode("/Configuration/RMM/Service_Server_Details").setAttribute("E_RMM_APP_Server_Path_M",$E_RMM_APP_Server_Path)
#RMM Rules_Folder
$xmlConfigFile.selectSingleNode("/Configuration/RMM/Rules_Folder").setAttribute("Export_Folder_Path_M",$Export_Folder_Path)
$xmlConfigFile.selectSingleNode("/Configuration/RMM/Rules_Folder").setAttribute("Import_Folder_Path_M",$Import_Folder_Path)
#RMM Private_Server_Details
$xmlConfigFile.selectSingleNode("/Configuration/RMM/Private_Server_Details").setAttribute("Private_Server_Name",$Private_Server_Name)
$xmlConfigFile.selectSingleNode("/Configuration/RMM/Private_Server_Details").setAttribute("Private_Server_Port",$Private_Server_Port)
#Additonal_CORS_Allowed_Origin
$xmlConfigFile.selectSingleNode("/Configuration/RMM/Additonal_CORS_Allowed_Origin").setAttribute("URL",$Additonal_CORS_Allowed_Origin)
#RMM Common
$xmlConfigFile.selectSingleNode("/Configuration/RMM/Common").setAttribute("SCHEDULER_INTERVAL",$RMM_SCHEDULER_INTERVAL)
$xmlConfigFile.selectSingleNode("/Configuration/RMM/Common").setAttribute("START_DELAY",$RMM_START_DELAY)
#RMM Authentication_Type
$xmlConfigFile.selectSingleNode("/Configuration/RMM/Authentication_Type").setAttribute("LDAP_Required",$LDAP_Required)
$xmlConfigFile.selectSingleNode("/Configuration/RMM/Authentication_Type").setAttribute("UAM_Required",$UAM_Required)
#RMM LDAP
$xmlConfigFile.selectSingleNode("/Configuration/RMM/LDAP").setAttribute("A_LDAP_Url",$A_LDAP_Url)
$xmlConfigFile.selectSingleNode("/Configuration/RMM/LDAP").setAttribute("B_LDAP_Domain",$B_LDAP_Domain)
$xmlConfigFile.selectSingleNode("/Configuration/RMM/LDAP").setAttribute("C_LDAP_Group_Name",$C_LDAP_Group_Name)
#RMM UAM
$xmlConfigFile.selectSingleNode("/Configuration/RMM/UAM").setAttribute("A_Auth_Web_Client_ID",$A_Auth_Web_ClientId)
$xmlConfigFile.selectSingleNode("/Configuration/RMM/UAM").setAttribute("B_Auth_App_Client_ID",$B_Auth_App_ClientId)
$xmlConfigFile.selectSingleNode("/Configuration/RMM/UAM").setAttribute("C_Auth_App_Client_Secret",$C_Auth_App_Client_Secret)
$xmlConfigFile.selectSingleNode("/Configuration/RMM/UAM").setAttribute("F_Admin_Console_Auth_Web_Client_ID",$F_Admin_Console_Auth_Web_Client_ID)
#JRE JRE_App
$xmlConfigFile.selectSingleNode("/Configuration/JRE/JRE_Components_Required").setAttribute("A_JRE_War_Required",$A_JRE_War_Required)
$xmlConfigFile.selectSingleNode("/Configuration/JRE/JRE_Components_Required").setAttribute("B_JRE_Properties_Required",$B_JRE_Properties_Required)
$xmlConfigFile.selectSingleNode("/Configuration/JRE/JRE_App_Path").setAttribute("JRE_App_Server_Path_M",$JRE_App_Server_Path)
#Framework_Web_Services
$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Framework_Web_Services_Components_Required").setAttribute("GPRO_Required",$GPRO_Required)
$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Framework_Web_Services_Components_Required").setAttribute("HEDIS_Submission_Required",$HEDIS_Submission_Required)
$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Framework_Web_Services_Components_Required").setAttribute("PMS_Required",$PMS_Required)
$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Framework_Web_Services_Components_Required").setAttribute("QPPDS_Required",$QPPDS_Required)
$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Framework_Web_Services_Components_Required").setAttribute("QPP_Required",$QPP_Required)
$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Framework_Web_Services_Components_Required").setAttribute("QRDAIII_Required",$QRDAIII_Required)
$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Framework_Web_Services_Components_Required").setAttribute("QRDAI_Required",$QRDAI_Required)
$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Framework_Web_Services_Components_Required").setAttribute("State_Level_Submission_Required",$State_Level_Submission_Required)
$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Framework_Web_Services_Components_Required").setAttribute("Wrapper_Services_Required",$Wrapper_Services_Required)
$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Framework_Web_Services_Components_Required").setAttribute("CohortQR_Required",$CohortQR_Required)
$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Year").setAttribute("GPRO_Year",$GPRO_Year)
$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Year").setAttribute("QPPDS_Year",$QPPDS_Year)
$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Year").setAttribute("QPP_Year",$QPP_Year)
$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Year").setAttribute("QRDAIII_Year",$QRDAIII_Year)
$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Year").setAttribute("QRDAI_Year",$QRDAI_Year)
$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Year").setAttribute("State_Level_Submission_Year",$State_Level_Submission_Year)
$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Year").setAttribute("CohortQR_Year",$CohortQR_Year)
#Framework_Web_Services UI_Server_Details_Framework
$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/UI_Server_Details_Framework").setAttribute("A_Framework_Web_Server_Name",$A_Framework_Web_Server_Name)
$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/UI_Server_Details_Framework").setAttribute("B_Framework_Web_Port",$B_Framework_Web_Port)
$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/UI_Server_Details_Framework").setAttribute("C_Framework_Web_Server_Path",$C_Framework_Web_Server_Path)
#Framework_Web_Services Service_Server_Details_Framework
$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Service_Server_Details_Framework").setAttribute("A_Framework_APP_Server_Name_M",$A_Framework_APP_Server_Name)
$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Service_Server_Details_Framework").setAttribute("B_Framework_APP_Port_M",$B_Framework_APP_Port)
$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Service_Server_Details_Framework").setAttribute("C_Framework_APP_Server_Path_M",$C_Framework_APP_Server_Path)
#Framework_Web_Services Wrapper_Service_Output_Folder_Path
$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Wrapper_Service").setAttribute("Output_Folder_Path",$Wrapper_Service_Output_Folder_Path)
#UAM Auth Client id
$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/UAM_Auth").setAttribute("Web_Client_ID",$FW_Auth_Web_ClientId)
$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/UAM_Auth").setAttribute("App_Client_ID",$App_Client_ID)
$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/UAM_Auth").setAttribute("App_client_Secret",$App_client_Secret)
#PerformPlus Auth Client id
$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Perform_Plus_UAM_Auth").setAttribute("Web_Client_ID",$PerformPlus_Web_Client_ID)
$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Perform_Plus_UAM_Auth").setAttribute("App_Client_ID",$PerformPlus_App_Client_ID)
$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Perform_Plus_UAM_Auth").setAttribute("App_Client_Secret",$PerformPlus_App_Client_Secret)
#Framework Private_Server_Details
$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Private_Server_Details_Framework").setAttribute("Private_Server_Name",$Framework_Private_Server_Name)
$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Private_Server_Details_Framework").setAttribute("Private_Server_Port",$Framework_Private_Server_Port)
$xmlConfigFile.Save($Setupconfigurationfile)
}
else
{
ECHO "DataRepresentation Config file not Exits"

}
