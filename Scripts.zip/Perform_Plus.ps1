﻿param([string]$SetupConfigurationFile,[string]$Value="NormalUpgrade",[string]$Upgrade="True")

function Write-HostWithLog{param([string]$Statement)
	$FileExists = Test-Path $LogFile
	If ($FileExists -eq $False) 
		{ New-Item $LogFile  -type file | Out-Null }
	$Date=Get-Date
	$DisplayStatement = $Date.ToString() + " " + $Statement
	Add-Content $LogFile $DisplayStatement
	Write-Host $Statement

}

#This function will Write to console with foreground color and in log file
function Write-HostWithLogandColor{param([string]$Statement,[string]$Color)
	$FileExists = Test-Path $LogFile
	If ($FileExists -eq $False) 
		{ New-Item $LogFile -type file | Out-Null }

	$Date=Get-Date
	$DisplayStatement = $Date.ToString() + " " + $Statement
	Add-Content $LogFile $DisplayStatement
	Write-Host $Statement -ForegroundColor $Color

}

function TestPath{param([string]$FolderPath,[string]$Message)
	if(Test-Path ($FolderPath))
	{
	Write-HostWithLogandColor $Temp Gray
	Write-HostWithLogandColor "$FolderPath $Message folder Path is valid" Gray
	Write-HostWithLogandColor $TempNewLine Gray
	}
	else
	{
	Write-HostWithLogandColor $TempNewLine Red
	Write-HostWithLogandColor "$FolderPath $Message folder path is invalid" Red
	Write-HostWithLogandColor $Temp Red
	throw "Please enter correct folder path"
	Exit 1;
	}
}

[xml]$xmlConfigFile = new-object XML
 
$config_file=$SetupConfigurationFile
$xmlConfigFile.Load($config_file)
	
	$LogFile_FolderPath=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/LogFile_FolderPath").getAttribute("Log_FolderPath_M")
	$LogFile=$LogFile_FolderPath + "\Log.txt"
	Write-HostWithLogandColor "Log Path $LogFile" Green
	
	$Build_Folder=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Build_FolderPath").getAttribute("Build_FolderPath_M")
	write-host "$Build_Folder path for build"
	$Build_FolderPath=$Build_Folder +"\Framework"
	TestPath $Build_FolderPath "Perform Plus Build"
Write-HostWithLog "#################################################################################"
Write-HostWithLog "#################################################################################"
Write-HostWithLog "## This Powershell is property of Citiustech"
Write-HostWithLog "## Do not make any changes without product team confirmation"
Write-HostWithLog "## Created by : Amit More"
Write-HostWithLog "## "
Write-HostWithLog "## Running Perform_Plus.ps1"
Write-HostWithLog "##Deploying PerformPlus application components on EAP/Wildfly server"
Write-HostWithLog "##"
Write-HostWithLog "##Do not close this window until deployment is successful"
Write-HostWithLog "#################################################################################"
Write-HostWithLog "#################################################################################"
	#Server Details

	$Clinical_DB_Server=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("A_Clinical_DB_Server_M")
	$Clinical_DB_Server=$Clinical_DB_Server.replace('\','\\')
	Write-HostWithLogandColor "Clinical DB Server: $Clinical_DB_Server" Gray
	$Clinical_DB_Port=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("C_Clinical_DB_Port_M")
	Write-HostWithLogandColor "Clinical DB Port: $Clinical_DB_Port" Gray
	$Clinical_SSIS_Server=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("B_Clinical_SSIS_Server_M")
	$Clinical_SSIS_Server=$Clinical_SSIS_Server.replace('\','\\')
	Write-HostWithLogandColor "Clinical SSIS Server: $Clinical_SSIS_Server" Gray
	$Clinical_SSIS_Port=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("C_Clinical_SSIS_Port_M")
	Write-HostWithLogandColor "Clinical SSIS Port: $Clinical_SSIS_Port" Gray
	
	$Clinical_DB_Name=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/BI_Clinical_Server_Details").getAttribute("D_Clinical_DB_Name_M")
	Write-HostWithLogandColor "Clinical DB Name: $Clinical_DB_Name" Gray
	#Web String
	$IsHttps_Required=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Web_String").getAttribute("IsHttps_Required")
	$IsSSO_Required=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Web_String").getAttribute("IsSSO_Required")
	
	#PerformPlus-APP
	$Perform_Plus_Required=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Framework_Web_Services_Components_Required").getAttribute("Perform_Plus_Required")
	$SourceForPerformPlusWarFiles=$Build_FolderPath+ "\JAVASolutions"+"\PerformPlus"+"\Build"
	#UI/Web server details
	$Framework_Web_Server_Name=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/UI_Server_Details_Framework").getAttribute("A_Framework_Web_Server_Name")
	$Framework_Web_Port=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/UI_Server_Details_Framework").getAttribute("B_Framework_Web_Port")
	$Framework_Web_Server_Path=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/UI_Server_Details_Framework").getAttribute("C_Framework_Web_Server_Path")
	#Service/App server details
	$Framework_APP_Server_Name=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Service_Server_Details_Framework").getAttribute("A_Framework_APP_Server_Name_M")
	$Framework_APP_Port=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Service_Server_Details_Framework").getAttribute("B_Framework_APP_Port_M")
	$Framework_APP_Server_Path=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Service_Server_Details_Framework").getAttribute("C_Framework_APP_Server_Path_M")
	
	#PrivateServiceServer
	$Private_Server_Name=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Private_Server_Details_Framework").getAttribute("Private_Server_Name")
	$Private_Server_Port=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Private_Server_Details_Framework").getAttribute("Private_Server_Port")
		
	$AbsolutefolderPathUIWar= $Framework_Web_Server_Path +"\standalone" + "\deployments"
	$AbsolutefolderPathServiceWar =$Framework_APP_Server_Path +"\standalone" +"\deployments"
	
	$DestinationForPerformPlusUIPropertiesFiles= $Framework_Web_Server_Path +"\modules"+"\system"+"\layers"+"\base"+"\com"+"\biclinical"+"\performplus"+"\configuration"+"\main"
	$PerformPlusWebBackupFolder= $Framework_Web_Server_Path +"\modules"+"\system"+"\layers"+"\base"+"\com"+"\biclinical"+"\performplus"+"\configuration"+"\BackupFolder_PerformPlus_Web"
	$DestinationForPerformPlusServicePropertiesFiles= $Framework_APP_Server_Path +"\modules"+"\system"+"\layers"+"\base"+"\com"+"\biclinical"+"\performplus"+"\configuration"+"\main"
	$PerformPlusAppBackupFolder= $Framework_APP_Server_Path +"\modules"+"\system"+"\layers"+"\base"+"\com"+"\biclinical"+"\performplus"+"\configuration"+"\BackupFolder_PerformPlus_App"
	
	$SourceForPerformPlusPropertiesFiles=$Build_FolderPath + "\JAVASolutions"+"\PerformPlus"+"\Utils"+"\properties"
	$SourceForDownloadFiles=$Build_FolderPath+"\JAVASolutions"+"\PerformPlus"+"\Utils"+"\downloads"
	$SQLAuth=$Build_FolderPath+"\JAVASolutions"+"\PerformPlus"+"\Utils"+"\bin"
	
	$Clinical_App_SQL_User=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Clinical_App_ConnectionString").getAttribute("B_Clinical_App_SQL_User")
	$Clinical_App_SQL_Password=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Clinical_App_ConnectionString").getAttribute("C_Clinical_App_SQL_Password")
	
	#SMTPDetails
	$SMTP_Server_Name=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/SMTP").getAttribute("A_SMTP_Server_Name")
	$SMTP_Port=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/SMTP").getAttribute("B_SMTP_Port")
	$SMTP_User_Name=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/SMTP").getAttribute("C_SMTP_User_Name")
	$SMTP_Password=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/SMTP").getAttribute("D_SMTP_Password")
	#MICROSOFT FolderPath
	$MicrosoftFolder=$Build_FolderPath+ "\JAVASolutions"+"\PerformPlus"+"\Utils"+"\modules"+"\system"+"\layers"+"\base"+"\com"+"\microsoft"+"\sqlserver"+"\main"
	$UploadMicrosoftFolder=$Framework_APP_Server_Path + "\modules" + "\system" + "\layers" + "\base" + "\com" + "\microsoft" +"\sqlserver" +"\main"
	
	#UAM User Access Management in Common paramaeters
	$UAMApp_Server_Name=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/UAM_Server_Details").getAttribute("UAMApp_Server_Name")
	$UAMApp_Server_Port=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/UAM_Server_Details").getAttribute("UAMApp_Server_Port")
	$UAMWeb_Server_Name=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/UAM_Server_Details").getAttribute("UAMWeb_Server_Name")
	$UAMWeb_Server_Port=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/UAM_Server_Details").getAttribute("UAMWeb_Server_Port")
	$Auth_Server_Name=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/UAM_Server_Details").getAttribute("Auth_Server_Name")
	$Auth_Server_Port=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/UAM_Server_Details").getAttribute("Auth_Server_Port")
	
	#UAM PerformPlus specific parameters
	$Auth_Web_ClientId=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Perform_Plus_UAM_Auth").getAttribute("Web_Client_ID")
	$Auth_App_ClientId=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Perform_Plus_UAM_Auth").getAttribute("App_Client_ID")
	$Auth_App_Client_Secret=$xmlConfigFile.selectSingleNode("/Configuration/Framework_Web_Services/Perform_Plus_UAM_Auth").getAttribute("App_Client_Secret")
	
	#RMM App server Details
	$RMM_APP_Server_Name=$xmlConfigFile.selectSingleNode("/Configuration/RMM/Service_Server_Details").getAttribute("C_RMM_APP_Server_Name_M")
	$RMM_APP_Port=$xmlConfigFile.selectSingleNode("/Configuration/RMM/Service_Server_Details").getAttribute("D_RMM_APP_Port_M")
	
	$DownloadFolderPathService=$Framework_APP_Server_Path + "\Downloads"

	if($Clinical_App_SQL_User -eq $null -or $Clinical_App_SQL_User -eq "")
	{
		$Clinical_App_SQL_User = ""
		$Clinical_App_SQL_Password = ""
		$ClinicalWindowsAuth = "True"
	}
	else
	{
	$Clinical_App_SQL_User=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Clinical_App_ConnectionString").getAttribute("B_Clinical_App_SQL_User")
	$Clinical_App_SQL_Password=$xmlConfigFile.selectSingleNode("/Configuration/Common_Parameter/Clinical_App_ConnectionString").getAttribute("C_Clinical_App_SQL_Password")
	$ClinicalWindowsAuth = "False"
	}
	
	if($Framework_Web_Port -eq "80" -or $Framework_Web_Port -eq "443")
	{
		$UIServerURL = $Framework_Web_Server_Name
	}
	else
	{
	$UIServerURL= $Framework_Web_Server_Name+":"+$Framework_Web_Port
	}
	if($Framework_APP_Port -eq "80" -or $Framework_APP_Port -eq "443")
	{
		$ServiceServerURL = $Framework_APP_Server_Name
	}
	else
	{
	$ServiceServerURL= $Framework_APP_Server_Name+":"+$Framework_APP_Port
	}
	if($Auth_Server_Port -eq "80" -or $Auth_Server_Port -eq "443")
	{
		$Auth_ServerURL = $Auth_Server_Name
	}
	else
	{
	$Auth_ServerURL= $Auth_Server_Name+":"+$Auth_Server_Port
	}
	if($UAMApp_Server_Port -eq "80" -or $UAMApp_Server_Port -eq "443")
	{
		$UAMAppServerURL = $UAMApp_Server_Name
	}
	else
	{
	$UAMAppServerURL= $UAMApp_Server_Name+":"+$UAMApp_Server_Port
	}
	if($UAMWeb_Server_Port -eq "80" -or $UAMWeb_Server_Port -eq "443")
	{
		$UAMWebServerURL = $UAMWeb_Server_Name
	}
	else
	{
	$UAMWebServerURL= $UAMWeb_Server_Name+":"+$UAMWeb_Server_Port
	}
	if($RMM_APP_Port -eq "80" -or $RMM_APP_Port -eq "443")
	{
		$RMMServerURL = $RMM_APP_Server_Name
	}
	else
	{
		$RMMServerURL= $RMM_APP_Server_Name+":"+$RMM_APP_Port
	}
	if ($Private_Server_Name -eq $null -or $Private_Server_Name -eq "" -and $Private_Server_Port -eq "" -or $Private_Server_Port -eq "")
	{
	$PrivateServiceServerURL=$ServiceServerURL
	$ValidHostUI=$UIServerURL+","+$ServiceServerURL
	$ValidHostService=$ServiceServerURL+","+$UIServerURL
	}
	elseif($Private_Server_Port -eq "80" -or $Private_Server_Port -eq "443")
	{
	$PrivateServiceServerURL=$Private_Server_Name
	$ValidHostUI=$UIServerURL+","+$ServiceServerURL+","+$PrivateServiceServerURL
	$ValidHostService=$ServiceServerURL+","+$UIServerURL+","+$PrivateServiceServerURL
	}
	else
	{
	$PrivateServiceServerURL=$Private_Server_Name+":"+$Private_Server_Port
	$ValidHostUI=$UIServerURL+","+$ServiceServerURL+","+$PrivateServiceServerURL
	$ValidHostService=$ServiceServerURL+","+$UIServerURL+","+$PrivateServiceServerURL
	}
	
	if ($IsHttps_Required -eq "True")
	{
	$UIServer="https://"+$UIServerURL
	$ServiceServer="https://"+$ServiceServerURL
	$Auth_Server="https://"+$Auth_ServerURL
	$UAMAPPServer="https://"+$UAMAppServerURL
	$UAMWebServer="https://"+$UAMWebServerURL
	$PrivateServiceServer="https://"+$PrivateServiceServerURL
	$RMMServerURL="https://"+$RMMServerURL
	}
	else
	{
	$UIServer="http://"+$UIServerURL
	$ServiceServer="http://"+$ServiceServerURL
	$Auth_Server="http://"+$Auth_ServerURL
	$UAMAPPServer="http://"+$UAMAppServerURL
	$UAMWebServer="http://"+$UAMWebServerURL
	$PrivateServiceServer="http://"+$PrivateServiceServerURL
	$RMMServerURL="http://"+$RMMServerURL
	}
	
#####CorsAllowedOrigins####
	if ($ServiceServer -eq $UIServer)
	{
	$CorsAllowedOriginsService=$ServiceServer
	}
	else
	{
	$CorsAllowedOriginsService=$ServiceServer+","+$UIServer
	}
	
	if ($UIServer -eq $UAMWebServer)
	{
	$CorsAllowedOrigins_Web=$UIServer
	}
	else
	{
	$CorsAllowedOrigins_Web=$UIServer+","+$UAMWebServer
	}
	if ($ServiceServer -eq $UAMAPPServer)
	{
	$CorsAllowedOrigins_App=$ServiceServer
	}
	else
	{
	$CorsAllowedOrigins_App=$ServiceServer+","+$UAMAPPServer
	}
	if ($CorsAllowedOrigins_Web -eq $CorsAllowedOrigins_App)
	{
	$CorsAllowedOriginsUI=$CorsAllowedOrigins_Web
	}
	else
	{
	$CorsAllowedOriginsUI=$CorsAllowedOrigins_Web+","+$CorsAllowedOrigins_App
	}
	if ($Auth_Server_Name -eq $null -or $Auth_Server_Name -eq "")
	{
	Write-HostWithLogandColor $CorsAllowedOriginsUI magenta
	}
	else
	{
	$CorsAllowedOriginsUI=$CorsAllowedOriginsUI+","+$Auth_Server
		Write-HostWithLogandColor $CorsAllowedOriginsUI magenta
	}
	if ($Private_Server_Name -eq $null -or $Private_Server_Name -eq "")
	{
	}
	else
	{
	$CorsAllowedOriginsUI=$PrivateServiceServer+","+$CorsAllowedOriginsUI
	}
	if ($Additonal_CORS_Allowed_Origin -eq $null -or $Additonal_CORS_Allowed_Origin -eq "")
	{
	}
	else{
	$CorsAllowedOriginsUI=$CorsAllowedOriginsUI+","+$Additonal_CORS_Allowed_Origin
	}

####Valid Host URL Secion####
	if ($Private_Server_Name -eq $null -or $Private_Server_Name -eq "" -and $Private_Server_Port -eq "" -or $Private_Server_Port -eq "")
	{
	$PrivateServiceServerBICConsoleURL=$ServiceServerURL
	$ValidHostBICConsoleUI=$UIServerURL
	$ValidHostBICConsoleService=$ServiceServerURL
	}
	elseif($Private_Server_Port -eq "80" -or $Private_Server_Port -eq "443")
	{
	$PrivateServiceServerBICConsoleURL=$Private_Server_Name
	$ValidHostBICConsoleUI=$UIServerURL
	$ValidHostBICConsoleService=$PrivateServiceServerBICConsoleURL+","+$ServiceServerURL
	}
	else
	{
	$PrivateServiceServerBICConsoleURL=$Private_Server_Name+":"+$Private_Server_Port
	$ValidHostBICConsoleUI=$UIServerURL
	$ValidHostBICConsoleService=$PrivateServiceServerBICConsoleURL+","+$ServiceServerURL
	}
	
#PerformPlus-APP
Write-HostWithLogandColor $dashline Gray 

if ([string] $Perform_Plus_Required -eq "False")
{}
else{
Write-HostWithLogandColor "Started PerformPlus Application Deployment" Yellow
Try
{
TestPath $Framework_APP_Server_Path "PerformPlus App Server EAP"
#regionBackupPerformPlusAppProperties
if ((Test-Path $PerformPlusAppBackupFolder) -eq $False)
{
Write-HostWithLogandColor $dashline Gray 
write-HostWithLogandColor "Create $PerformPlusAppBackupFolder Folder on App Server"Gray
New-Item ($PerformPlusAppBackupFolder) -type directory -force | out-null
}
else
{
write-HostWithLogandColor "$PerformPlusAppBackupFolder Folder already exist on App Server" Yellow
}
Write-HostWithLogandColor $dashline Gray 
if (Test-Path "$DestinationForPerformPlusServicePropertiesFiles\*.properties")
{
write-HostWithLogandColor "Backup PerformPlus App Properties files to $PerformPlusAppBackupFolder" Yellow
robocopy $DestinationForPerformPlusServicePropertiesFiles $PerformPlusAppBackupFolder
write-HostWithLogandColor "Backup of PerformPlus App Properties file is completed to $PerformPlusAppBackupFolder" Yellow
}
Write-HostWithLogandColor $dashline Gray 
#endregionregionBackupPerformPlusAppProperties

Write-HostWithLogandColor "Copying properties files to the Service WildFlyFolderPath" Yellow

if (Test-Path ($DestinationForPerformPlusServicePropertiesFiles))
{}
else
{New-Item ($DestinationForPerformPlusServicePropertiesFiles) -type directory -force | out-null}
if (Test-Path "$SourceForPerformPlusPropertiesFiles\database.properties")
{Get-Content "$SourceForPerformPlusPropertiesFiles\database.properties" | ForEach-Object { $_ -replace "<db-server-name>","$Clinical_DB_Server" -replace "<Database-Name>","$Clinical_DB_Name" -replace "<db-port>","$Clinical_DB_Port" -replace "<User-Name>","$Clinical_App_SQL_User" -replace "<encrypted-database-password>","$Clinical_App_SQL_Password" -replace "<isWindowsAuthentication>","$ClinicalWindowsAuth" } | Set-Content "$DestinationForPerformPlusServicePropertiesFiles\database.properties"}

if (Test-Path "$SourceForPerformPlusPropertiesFiles\performplusconfig.properties")
{Get-Content "$SourceForPerformPlusPropertiesFiles\performplusconfig.properties" | ForEach-Object { $_ -replace "<UIServerURL>","$UIServer" -replace "<ServiceServerURL>","$ServiceServer" -replace "<SmtpEncryptedHostServer>","$SMTP_Server_Name" -replace "<SmtpPort>","$SMTP_Port" -replace "<SmtpUserName>","$SMTP_User_Name" -replace "<SmtpEncryptedPasswaord>","$SMTP_Password" -replace "<IsSSOEnabled>","$IsSSO_Required" -replace "<IsHTTPSEnabled>","$IsHttps_Required" -replace "<UAMServerURL>","$UAMAPPServer" -replace "<AuthWebClientId>","$Auth_Web_ClientId" -replace "<AuthAppClientId>","$Auth_App_ClientId" -replace "<AuthAppEncryptedClientSecretId>","$Auth_App_Client_Secret" -replace "<AppCorsAllowedOrigins>","$CorsAllowedOriginsService" -replace "<UAMWebAppServerURL>","$UAMWebServer" -replace "<PrivateServiceServerURL>","$PrivateServiceServer" -replace "<ValidHosts>","$ValidHostService" -replace "<RMMServerURL>","$RMMServerURL" } | Set-Content "$DestinationForPerformPlusServicePropertiesFiles\performplusconfig.properties"}

if (Test-Path "$SourceForPerformPlusPropertiesFiles\auth.properties")
{get-childitem -path "$SourceForPerformPlusPropertiesFiles\auth.properties"| Copy-Item -destination "$DestinationForPerformPlusServicePropertiesFiles\auth.properties"}

if (Test-Path "$SourceForPerformPlusPropertiesFiles\application.properties")
{get-childitem -path "$SourceForPerformPlusPropertiesFiles\application.properties"| Copy-Item -destination "$DestinationForPerformPlusServicePropertiesFiles\application.properties"}

get-childitem -path $SourceForPerformPlusPropertiesFiles -recurse -include *.xml | Copy-Item -destination "$DestinationForPerformPlusServicePropertiesFiles"

Write-HostWithLogandColor "Copied properties files to the Service WildFlyFolderPath" Green

#War deployment
TestPath $AbsolutefolderPathServiceWar
#regionBackupPerformPlusAppwar
Write-HostWithLogandColor $dashline Gray 
if (Test-Path "$AbsolutefolderPathServiceWar\*.war")
{
write-HostWithLogandColor "Backup PerformPlus App war files to $PerformPlusAppBackupFolder" Yellow
robocopy $AbsolutefolderPathServiceWar $PerformPlusAppBackupFolder
write-HostWithLogandColor "Backup of PerformPlus App war file is completed to $PerformPlusAppBackupFolder" Yellow
}
Write-HostWithLogandColor $dashline Gray 
#endregionregionBackupPerformPlusAppwar
Write-HostWithLogandColor "Started copying War deployment on service Wildfly server" Yellow
if((Test-Path $AbsolutefolderPathServiceWar) -eq $False)
{
	New-Item ($AbsolutefolderPathServiceWar) -type directory -force | out-null
}

if ((Test-Path "$SourceForPerformPlusWarFiles" ) -and [string]$Perform_Plus_Required -eq "true" )
{
get-childitem -path $SourceForPerformPlusWarFiles -recurse -Include "PerformPlus.war" | Copy-Item -Destination "$AbsolutefolderPathServiceWar"
}
Write-HostWithLogandColor "Deployment of War is done on $Framework_APP_Server_Path " Green

if (Test-Path ($DownloadFolderPathService))
{}
else
{New-Item ($DownloadFolderPathService) -type directory -force | out-null}
get-childitem -path $SourceForDownloadFiles -recurse -include *.xlsx ,*.png , *.ttf , *.xsl , *.jrxml | Copy-Item -destination "$DownloadFolderPathService"

if (Test-Path ($UploadMicrosoftFolder))
{}
else
{New-Item ($UploadMicrosoftFolder) -type directory -force | out-null}
robocopy "$MicrosoftFolder" "$UploadMicrosoftFolder" /e

get-childitem -path $SQLAuth -recurse *.dll | Copy-Item -destination "$Framework_APP_Server_Path\bin"

Write-HostWithLogandColor "Kindly Restart PerformPlus Webbapp WildFly Application Service" Yellow

Write-HostWithLogandColor $Dashline Gray

#Deployment of UI components on UI server

TestPath $Framework_Web_Server_Path "PerformPlus Web Server EAP"
#regionBackupPerformPlusWebProperties
if ((Test-Path $PerformPlusWebBackupFolder) -eq $False)
{
Write-HostWithLogandColor $dashline Gray 
write-HostWithLogandColor "Create $PerformPlusWebBackupFolder Folder on UI Server"Gray
New-Item ($PerformPlusWebBackupFolder) -type directory -force | out-null
}
else
{
write-HostWithLogandColor "$PerformPlusWebBackupFolder Folder already exist on UI Server" Yellow
}
Write-HostWithLogandColor $dashline Gray 
if (Test-Path "$DestinationForPerformPlusUIPropertiesFiles\*.properties")
{
write-HostWithLogandColor "Backup PerformPlus UI Properties files to $PerformPlusWebBackupFolder" Yellow
robocopy $DestinationForPerformPlusUIPropertiesFiles $PerformPlusWebBackupFolder
write-HostWithLogandColor "Backup of PerformPlus UI Properties file is completed to $PerformPlusWebBackupFolder" Yellow
}
Write-HostWithLogandColor $dashline Gray 
#endregionregionBackupPerformPlusWebProperties
Write-HostWithLogandColor "Copying properties files to the UI WildFlyFolderPath" Yellow

if (Test-Path ($DestinationForPerformPlusUIPropertiesFiles))
{}
else
{New-Item ($DestinationForPerformPlusUIPropertiesFiles) -type directory -force | out-null}
if (Test-Path "$SourceForPerformPlusPropertiesFiles\performplusweb.properties")
{Get-Content "$SourceForPerformPlusPropertiesFiles\performplusweb.properties" | ForEach-Object { $_ -replace "<UIServerURL>","$UIServer" -replace "<ServiceServerURL>","$ServiceServer" -replace "<IsSSOEnabled>","$IsSSO_Required" -replace "<IsHTTPSEnabled>","$IsHttps_Required" -replace "<UAMServerURL>","$UAMAPPServer" -replace "<AuthWebClientId>","$Auth_Web_ClientId" -replace "<AuthAppClientId>","$Auth_App_ClientId" -replace "<AuthAppEncryptedClientSecretId>","$Auth_App_Client_Secret" -replace "<WebCorsAllowedOrigins>","$CorsAllowedOriginsUI" -replace "<UAMWebAppServerURL>","$UAMWebServer" -replace "<PrivateServiceServerURL>","$PrivateServiceServer" -replace "<WebValidHosts>","$ValidHostUI" } | Set-Content "$DestinationForPerformPlusUIPropertiesFiles\performplusweb.properties"} 

if (Test-Path "$SourceForPerformPlusPropertiesFiles\auth.properties")
{get-childitem -path "$SourceForPerformPlusPropertiesFiles\auth.properties"| Copy-Item -destination "$DestinationForPerformPlusUIPropertiesFiles\auth.properties"}

if (Test-Path "$SourceForPerformPlusPropertiesFiles\application.properties")
{get-childitem -path "$SourceForPerformPlusPropertiesFiles\application.properties"| Copy-Item -destination "$DestinationForPerformPlusUIPropertiesFiles\application.properties"}

get-childitem -path $SourceForPerformPlusPropertiesFiles -recurse -include *.xml | Copy-Item -destination "$DestinationForPerformPlusUIPropertiesFiles"

Write-HostWithLogandColor "Copied properties files to the WildFlyFolderPath UI Server" Green


TestPath $AbsolutefolderPathUIWar

#regionBackupPerformPlusWebwar
Write-HostWithLogandColor $dashline Gray 
if (Test-Path "$AbsolutefolderPathUIWar\*.war")
{
write-HostWithLogandColor "Backup PerformPlus war files to $PerformPlusWebBackupFolder" Yellow
robocopy $AbsolutefolderPathUIWar $PerformPlusWebBackupFolder
write-HostWithLogandColor "Backup of PerformPlus war file is completed to $PerformPlusWebBackupFolder" Yellow
}
Write-HostWithLogandColor $dashline Gray 
#endregionregionBackupPerformPlusWebwar
Write-HostWithLogandColor "Started copying War deployment on UI Wildfly Server" Yellow
if((Test-Path $AbsolutefolderPathUIWar) -eq $False)
{
	New-Item ($AbsolutefolderPathUIWar) -type directory -force | out-null
}
if ((Test-Path "$SourceForPerformPlusWarFiles" ) -and [string]$Perform_Plus_Required -eq "true" )
{
get-childitem -path $SourceForPerformPlusWarFiles -recurse -include "PerformPlusWeb.war" | Copy-Item -destination "$AbsolutefolderPathUIWar"
}
Write-HostWithLogandColor "Deployment of War is done on $Framework_APP_Server_Path Server" Green

get-childitem -path $SQLAuth -recurse *.dll | Copy-Item -destination "$Framework_APP_Server_Path\bin"


}

Catch
{
Write-HostWithLogandColor $_.Exception.GetType( ).FullName Red
exit 1;
}
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor "Deployment of PerformPlus application is done successfully" Green
Write-HostWithLogandColor $dashline Gray
Write-HostWithLogandColor $dashline Gray
}

