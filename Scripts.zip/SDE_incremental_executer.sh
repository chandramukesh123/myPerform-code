#!/bin/bash
#############################################################################################################################
#############################################################################################################################
##################################################### PROPERTY OF CITIUSTECH ######################################################################################################                        #################################################
####################################################CREATED BY : UMANG KUMAR #############################################################################################################################################################################################################################################################################################################
############################################################################################################################################################################################################################################################

# Purpose : to fetch inremental data from Git 
# Parameter required : 
#				1.) base tag --			eg :  -b=1.0
#				2.) current tag --		eg :  -c=1.8 
#				3.) build path --		eg :  -p=/d/git_poc
#Note :  directory structure of current repository should be same as of skeleton build path . 

echo -e  '\e[32m Execution started at :   '$(date)   
echo   'Welcome Devops '
for i in "$@"
do
case $i in
    -b=*|--basetag=*)
    INITIALTAG="${i#*=}"

    ;;
    -c=*|--currenttag=*)
    CURRENTTAG="${i#*=}"
    ;;
    -p=*|--buildpath=*)
    BUILDPATH="${i#*=}"
    ;;
    --default)
    DEFAULT=YES
    ;;
    *)
            # unknown option
    ;;
esac
done
INITIALTAG=$( echo "$INITIALTAG"    | sed "s/ //g" )
CURRENTTAG=$( echo "$CURRENTTAG"    | sed "s/ //g" )
BUILDPATH=$( echo "$BUILDPATH"     | sed "s/ //g" )


echo INITIAL TAG = ${INITIALTAG}
echo CURRENT TAG = ${CURRENTTAG}
echo BUILD PATH = ${BUILDPATH}
#echo DEFAULT = ${DEFAULT}

if  [ -z "$INITIALTAG" -o "$INITIALTAG" == " " ] || [ -z "$CURRENTTAG" -o "$CURRENTTAG" == " " ] ||  [ -z "$BUILDPATH" -o "$BUILDPATH" == " " ] 
	then
		echo 'all three fields INITIALTAG,CURRENTTAG,BUILDPATH are mandatory for process execution'
		echo 'stopping process ... '
		exit 1;
else
	echo " Necessary fields are valid"
	echo " Continuing with the process ..."
fi

		
`git diff  ${INITIALTAG}  ${CURRENTTAG} --name-only ":(exclude)*/UI/*" > ${BUILDPATH}/incremental-file-list.txt`
 if [ $? -gt 0 ];
 	then
		echo	"Git command failed to execute there is issue with script .Kindly debug"
		echo 	" stopping the process ..."
		exit 1
 fi		
PARENTBUILDPATH="$(dirname "$BUILDPATH")"
echo "PARENT DIRECTORY : " $PARENTBUILDPATH

ABSOLUTEFILEPATH=${BUILDPATH}/incremental-file-list.txt
echo "incremental filelist path : " $ABSOLUTEFILEPATH ;

##
STATICFILEPATH=${BUILDPATH}/ReleaseManagement/ComponentList/SDEComponentList.txt
vim $STATICFILEPATH -c "set ff=unix" -c ":wq"
COMMONFILEPATH=${BUILDPATH}/common-file-list.txt
echo "static filelist path : " $STATICFILEPATH ;
if [ ! -f $STATICFILEPATH  ] ;
    then
        echo "no static file exist there might be some issue in script. Kindly debug"
        echo "stopping the process ..."
        exit 1

else
    if [ ! -s $STATICFILEPATH ] ;
         then 
             echo "No static data exist"
             echo "program executed successfully. thank you"
    else
           echo "Moving common file into common-file-list.txt"
           
           comm -12 <(sort $ABSOLUTEFILEPATH) <(sort $STATICFILEPATH) >  $COMMONFILEPATH
           echo "Common file path executed successfully"
     fi
	 fi
     
##



echo "incremental filelist path : " $COMMONFILEPATH ;
if [ ! -f $COMMONFILEPATH  ] ;
	then 
		echo "no incremental file exist there might be some issue in script .Kindly debug"
		echo "stopping the process ..."
		exit 1

else
	if [ ! -s $COMMONFILEPATH ] ;
		then
			echo "No incremental data exist "
			echo "programm executed successfully . thank you"
			#exit 1
	else		
			echo "Filelist is given below"
			counter=1
		while IFS= read -r line 
			do
				# counter=1
				fileList=`echo $line | cut -d$' ' -f2`
				echo " $counter . " $fileList
				`cp $fileList $BUILDPATH/$fileList`
				counter=$((counter+1))
			done < "$COMMONFILEPATH"		
	fi			
	fi		


echo "end of code "
echo " thanks"
